package com.personal.saurabhp.order.exception;

public class InfyMarketException extends Exception {

	private static final long serialVersionUID = 1L;

	public InfyMarketException(String message) {
		super(message);
	}

}
